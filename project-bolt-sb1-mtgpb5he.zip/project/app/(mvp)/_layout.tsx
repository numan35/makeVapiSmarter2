import 'react-native-gesture-handler';
import { Stack } from 'expo-router';

export default function MvpLayout() {
  return <Stack screenOptions={{ headerShown: true }} />;
}
